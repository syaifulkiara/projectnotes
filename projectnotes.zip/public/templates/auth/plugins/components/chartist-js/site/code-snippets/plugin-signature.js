function myChartistPlugin(chart) {

}
